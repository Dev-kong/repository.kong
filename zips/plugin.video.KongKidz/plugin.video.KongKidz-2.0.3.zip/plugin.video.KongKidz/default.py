#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import Login
import Main

import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon

#############################################################
#################### SET ADDON ID ###########################
_addon_id_	= 'plugin.video.KongKidz'
_self_			= xbmcaddon.Addon(id=_addon_id_)
addon				= Addon(_addon_id_, sys.argv)

def START():

	try:
		if _self_.getSetting('Username') == "":
			Login.LoginWindow()
		else:
			Main.MainWindow()
			
	except (RuntimeError, SystemError):
		pass

START()