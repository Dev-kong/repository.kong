#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import os
import sys
from random import randint
import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon

#############################################################
#################### SET ADDON ID ###########################
_addon_id_ = 'plugin.video.Kongspock'
_self_ = xbmcaddon.Addon(id=_addon_id_)
addon = Addon(_addon_id_, sys.argv)
_images_ = '/resources/gui/'


#############################################################
#################### SET ADDON THEME IMAGES #################
Icon = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_, 'Icon.png'))
FanArt = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_, 'Fanart.png'))
Background_Image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'bg.png'))
Rock = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'rock.png'))
Paper = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'paper.png'))
Scissors = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'scissors.png'))
Spock = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'spock.png'))
Rock_nf = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'rocknf.png'))
Paper_nf = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'papernf.png'))
Scissors_nf = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'scissorsnf.png'))
Spock_nf = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'spocknf.png'))
you = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'you.png'))
spocc = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'spoc.png'))
wrong = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'wrong.mp3'))
win = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'win.mp3'))

you_score_int = 0
spock_score_int = 0

def run():
	
	window = Main('Kongspock')
	window.doModal()
	del window


def Random_Hand(self):

	random_hand = randint(0, 4)

	if random_hand <= 1:
		spocks_hand_code = "Rock"
	elif random_hand <= 2:
		spocks_hand_code = "Paper"
	elif random_hand <= 3:
		spocks_hand_code = "Scissors"
	elif random_hand <= 4:
		spocks_hand_code = "Spock"
	else:
		spocks_hand_code = "Rock"

	return spocks_hand_code


def Play(self, userhand):
	global you_score_int
	global spock_score_int

	spocks_hand = Random_Hand(self)

	if spocks_hand == userhand:
		self.Header.setText("Its A Tie! You Both Selected : " + userhand)
		play_title = "It's A Tie!"

	elif spocks_hand == "Rock":
		if userhand == "Paper" or userhand == "Spock":
			self.Header.setText("You WIN! Spock Selected : " + spocks_hand)
			play_title = "You Win!"
		else:
			self.Header.setText("You Lose! Spock Selected : " + spocks_hand)
			play_title = "You Lose!"

	elif spocks_hand == "Paper":
		if userhand == "Scissors":
			self.Header.setText("You WIN! Spock Selected : " + spocks_hand)
			play_title = "You Win!"
		else:
			self.Header.setText("You Lose! Spock Selected : " + spocks_hand)
			play_title = "You Lose!"

	elif spocks_hand == "Scissors":
		if userhand == "Rock" or userhand == "Spock":
			self.Header.setText("You WIN! Spock Selected : " + spocks_hand)
			play_title = "You Win!"
		else:
			self.Header.setText("You Lose! Spock Selected : " + spocks_hand)
			play_title = "You Lose!"

	elif spocks_hand == "Spock":
		if userhand == "Paper":
			self.Header.setText("You WIN! Spock Selected : " + spocks_hand)
			play_title = "You Win!"

		else:
			self.Header.setText("You Lose! Spock Selected : " + spocks_hand)
			play_title = "You Lose!"
			
	
	if 'Win' in play_title:
		you_score_int = you_score_int + 1
		self.You_Score.setText(str(you_score_int))
		play_tune = win
		
	elif 'Lose' in play_title:
		spock_score_int = spock_score_int + 1
		self.Spock_Score.setText(str(spock_score_int))
		play_tune = wrong
	
	else:
		play_tune = wrong
		
	Show_List	=	xbmcgui.ListItem(play_title, iconImage=Icon,thumbnailImage=Icon)
	xbmc.Player().play(play_tune, Show_List, False)

#############################################################
######### Class Containing the GUi Code / Controls ##########
class Main(pyxbmct.AddonFullWindow):

    xbmc.executebuiltin("Dialog.Close(busydialog)")

    def __init__(self, title='Kongspock'):
        super(Main, self).__init__(title)
		
		#set the location and size of your window in kodi
        self.setGeometry(1280, 720, 100, 50)
		
		## Set The backGround Image using PYX Image
        Background = pyxbmct.Image(Background_Image)
		
		## Place The BackGround Image (X, Y, W, H)
        self.placeControl(Background, -9, -5, 125, 56)
		
		## function to set information controls none interactive
        self.set_info_controls()
		
		## function to set active controls that users interact with 
        self.set_active_controls()
		
		## function to set what happens when users press left,right,up,down on your active controls
        self.set_navigation()
		
		## connect the back button to pyx to close window
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.connect(self.Rock,lambda:Play(self, 'Rock'))
        self.connect(self.Paper,lambda:Play(self, 'Paper'))
        self.connect(self.Scissors,lambda:Play(self, 'Scissoes'))
        self.connect(self.Spock, lambda:Play(self, 'Spock'))
		
        self.Header.setText('Select An Option To Play.')
        self.You_Score.setText('0')
        self.Spock_Score.setText('0')
        self.setFocus(self.Spock)


    def set_info_controls(self):
	
        self.Header	=	pyxbmct.TextBox()
        self.placeControl(self.Header, 1, 20, 40, 10)

        self.You_Score	=	pyxbmct.TextBox()
        self.placeControl(self.You_Score, 95, 16, 40, 10)

        self.Spock_Score	=	pyxbmct.TextBox()
        self.placeControl(self.Spock_Score, 95, 32, 40, 10)
		
        self.Show_you = pyxbmct.Image(you)
        self.placeControl(self.Show_you, 90, 15, 6, 3)

        self.Show_spoc = pyxbmct.Image(spocc)
        self.placeControl(self.Show_spoc, 90, 31, 6, 3)

    def set_active_controls(self):
        self.Rock		= pyxbmct.Button('',	focusTexture=Rock,	noFocusTexture=Rock_nf)
        self.Paper		= pyxbmct.Button('',	focusTexture=Paper,	noFocusTexture=Paper_nf)
        self.Scissors	= pyxbmct.Button('',	focusTexture=Scissors,	noFocusTexture=Scissors_nf)
        self.Spock		= pyxbmct.Button('',	focusTexture=Spock,	noFocusTexture=Spock_nf)

        self.placeControl(self.Rock,55, 10,  15, 4)
        self.placeControl(self.Paper,75, 23, 15, 4)
        self.placeControl(self.Scissors ,55, 35, 15, 4)
        self.placeControl(self.Spock,20, 20, 40, 10)


    def set_navigation(self):
		self.Rock.controlRight(self.Scissors)
		self.Rock.controlLeft(self.Scissors)
		self.Rock.controlDown(self.Paper)
		self.Rock.controlUp(self.Spock)
		self.Scissors.controlRight(self.Rock)
		self.Scissors.controlLeft(self.Rock)
		self.Scissors.controlDown(self.Paper)
		self.Scissors.controlUp(self.Spock)
		self.Spock.controlRight(self.Scissors)
		self.Spock.controlLeft(self.Rock)
		self.Spock.controlDown(self.Paper)
		self.Spock.controlUp(self.Paper)
		self.Paper.controlRight(self.Scissors)
		self.Paper.controlLeft(self.Rock)
		self.Paper.controlDown(self.Spock)
		self.Paper.controlUp(self.Spock)

run()