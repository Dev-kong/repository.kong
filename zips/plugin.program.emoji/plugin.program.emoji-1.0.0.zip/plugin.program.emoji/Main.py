#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import urllib
import urllib2
import urlparse

import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon


#############################################################
#################### SET ADDON ID ###########################
_addon_id_	= 'plugin.program.emoji'
_self_			= xbmcaddon.Addon(id=_addon_id_)
#############################################################
#################### SET ADDON THEME DIRECTORY ##############
_theme_			= _self_.getSetting('Theme')
_images_		= '/resources/' + _theme_	
_baseURL_       = 'https://pastebin.com/raw/3ua89Bjv'
Emoji_id	=	''

#################### BACKGROUND IMAGE #################
Background_Image	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Background.png'))

#### GUESS/Space BUTTON SELECTED/UNSELECTED ####
Guess			= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Guess.png'))
Guess_Focused	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Guess-Selected.png'))
Space			= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Space.png'))
Space_Focused	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Space-S.png'))

#### NONE SELECTED LETTERS ####
A = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'A.png'))
B = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'B.png'))
C = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'C.png'))
D = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'D.png'))
E = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'E.png'))
F = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'F.png'))
G = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'G.png'))
H = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'H.png'))
I = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'I.png'))
J = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'J.png'))
K = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'K.png'))
L = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'L.png'))
M = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'M.png'))
N = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'N.png'))
O = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'O.png'))
P = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'P.png'))
Q = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Q.png'))
R = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'R.png'))
S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'S.png'))
T = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'T.png'))
U = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'U.png'))
V = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'V.png'))
W = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'W.png'))
X = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'X.png'))
Y = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Y.png'))
Z = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Z.png'))

#### SELECTED LETTERS ####
A_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'A-S.png'))
B_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'B-S.png'))
C_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'C-S.png'))
D_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'D-S.png'))
E_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'E-S.png'))
F_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'F-S.png'))
G_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'G-S.png'))
H_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'H-S.png'))
I_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'I-S.png'))
J_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'J-S.png'))
K_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'K-S.png'))
L_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'L-S.png'))
M_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'M-S.png'))
N_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'N-S.png'))
O_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'O-S.png'))
P_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'P-S.png'))
Q_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Q-S.png'))
R_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'R-S.png'))
S_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'S-S.png'))
T_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'T-S.png'))
U_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'U-S.png'))
V_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'V-S.png'))
W_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'W-S.png'))
X_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'X-S.png'))
Y_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Y-S.png'))
Z_S = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Z-S.png'))

#############################################################
########## Function To Call That Starts The Window ##########
def MainWindow():
	
    window = Main('Guess the Emoji')
    window.doModal()
    del window
	
def Get_Data(url):

    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0')
    response = urllib2.urlopen(req, timeout=30)
    data = response.read()
    response.close()

    return data
	
def Get_Emojis(self):

##########################: SET GLOBALS
	global Emoji_One
	global Emoji_Two
	global Emoji_Answear
	
	Emoji_One		=	[]
	Emoji_Two		=	[]
	Emoji_Answear	=	[]
	
	Emoji_XML = Get_Data(_baseURL_)
	Emojis = re.findall('<emoji><id>(.*?)</id><one>(.*?)</one><two>(.*?)</two><answear>(.*?)</answear></emoji>', Emoji_XML, re.DOTALL)

	for Emoji in Emojis:
		Emoji_One.append(Emoji[1])
		Emoji_Two.append(Emoji[2])
		Emoji_Answear.append(Emoji[3])
		
def Set_Emojis(self):

    global Emoji_ID
	
    Emoji_ID = int(_self_.getSetting('Emoji_ID'))

    self.Emoji_One_Image = pyxbmct.Image(xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + '/resources/emojis/', Emoji_One[Emoji_ID]+'.png')))
    self.placeControl(self.Emoji_One_Image, 9, 10, 36, 10)
		
    self.Emoji_Two_Image = pyxbmct.Image(xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + '/resources/emojis/', Emoji_Two[Emoji_ID]+'.png')))
    self.placeControl(self.Emoji_Two_Image, 9, 28, 36, 10)
	
def Update_Emojis(self):
	
	global Emoji_ID
	
	Emoji_ID = int(_self_.getSetting('Emoji_ID'))
	
	self.Emoji_One_Image.setImage(xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + '/resources/emojis/', Emoji_One[Emoji_ID]+'.png')))
	self.Emoji_Two_Image.setImage(xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + '/resources/emojis/', Emoji_Two[Emoji_ID]+'.png')))
		
	
def set_Letters(self, letter):

	Answear_Text = self.Hello.getLabel()
	
	if Answear_Text == "GUESS THE EMOJI":
		self.Hello.setLabel(letter)
	elif Answear_Text == "CORRECT":
		self.Hello.setLabel(letter)
	else:
		self.Hello.setLabel(Answear_Text+letter)
		
def Check_Answear(self):

	Answear_Text = self.Hello.getLabel()
	New_ID = Emoji_ID + 1
	
	if Answear_Text == Emoji_Answear[Emoji_ID].upper():
		self.Hello.setLabel('CORRECT')
		_self_.setSetting('Emoji_ID', str(New_ID))
		Update_Emojis(self)
	else:
		self.Hello.setLabel('GUESS THE EMOJI')
		
######### Class Containing the GUi Code / Controls ##########
class Main(pyxbmct.AddonFullWindow):

    xbmc.executebuiltin("Dialog.Close(busydialog)")

    def __init__(self, title='Guess The Emoji'):
        super(Main, self).__init__(title)
		
		#set the location and size of your window in kodi
        self.setGeometry(1280, 720, 100, 50)
		
		## Set The backGround Image using PYX Image
        Background			= pyxbmct.Image(Background_Image)
		
		## Place The BackGround Image (X, Y, W, H)
        self.placeControl(Background, -10, -1, 123, 52)
		
		## function to set information controls none interactive
        self.set_info_controls()
		
		## function to set active controls that users interact with 
        self.set_active_controls()
		
		## function to set what happens when users press left,right,up,down on your active controls
        self.set_navigation()
		
		## connect the back button to pyx to close window
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.connect(self.Space_Button, lambda:set_Letters(self,' '))
        self.connect(self.A_Button, lambda:set_Letters(self,'A'))
        self.connect(self.B_Button, lambda:set_Letters(self,'B'))
        self.connect(self.C_Button, lambda:set_Letters(self,'C'))
        self.connect(self.D_Button, lambda:set_Letters(self,'D'))
        self.connect(self.E_Button, lambda:set_Letters(self,'E'))
        self.connect(self.F_Button, lambda:set_Letters(self,'F'))
        self.connect(self.G_Button, lambda:set_Letters(self,'G'))
        self.connect(self.H_Button, lambda:set_Letters(self,'H'))
        self.connect(self.I_Button, lambda:set_Letters(self,'I'))
        self.connect(self.J_Button, lambda:set_Letters(self,'J'))
        self.connect(self.K_Button, lambda:set_Letters(self,'K'))
        self.connect(self.L_Button, lambda:set_Letters(self,'L'))
        self.connect(self.M_Button, lambda:set_Letters(self,'M'))
        self.connect(self.N_Button, lambda:set_Letters(self,'N'))
        self.connect(self.O_Button, lambda:set_Letters(self,'O'))
        self.connect(self.P_Button, lambda:set_Letters(self,'P'))
        self.connect(self.Q_Button, lambda:set_Letters(self,'Q'))
        self.connect(self.R_Button, lambda:set_Letters(self,'R'))
        self.connect(self.S_Button, lambda:set_Letters(self,'S'))
        self.connect(self.T_Button, lambda:set_Letters(self,'T'))
        self.connect(self.U_Button, lambda:set_Letters(self,'U'))
        self.connect(self.V_Button, lambda:set_Letters(self,'V'))
        self.connect(self.W_Button, lambda:set_Letters(self,'W'))
        self.connect(self.X_Button, lambda:set_Letters(self,'X'))
        self.connect(self.Y_Button, lambda:set_Letters(self,'Y'))
        self.connect(self.Z_Button, lambda:set_Letters(self,'Z'))
        self.connect(self.Guess_Button, lambda:Check_Answear(self))
		
        Get_Emojis(self)
        Set_Emojis(self)
        self.setFocus(self.A_Button)


    def set_info_controls(self):
	
		## create and place a static information able control
        self.Hello = pyxbmct.Label('GUESS THE EMOJI',font='font8', alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.Hello, 65, 1, 2, 49)


    def set_active_controls(self):
		
		#Create a single Button Eliment
        self.A_Button	= pyxbmct.Button('',	focusTexture=A_S,	noFocusTexture=A)
        self.B_Button	= pyxbmct.Button('',	focusTexture=B_S,	noFocusTexture=B)
        self.C_Button	= pyxbmct.Button('',	focusTexture=C_S,	noFocusTexture=C)
        self.D_Button	= pyxbmct.Button('',	focusTexture=D_S,	noFocusTexture=D)
        self.E_Button	= pyxbmct.Button('',	focusTexture=E_S,	noFocusTexture=E)
        self.F_Button	= pyxbmct.Button('',	focusTexture=F_S,	noFocusTexture=F)
        self.G_Button	= pyxbmct.Button('',	focusTexture=G_S,	noFocusTexture=G)
        self.H_Button	= pyxbmct.Button('',	focusTexture=H_S,	noFocusTexture=H)
        self.I_Button	= pyxbmct.Button('',	focusTexture=I_S,	noFocusTexture=I)
        self.J_Button	= pyxbmct.Button('',	focusTexture=J_S,	noFocusTexture=J)
        self.K_Button	= pyxbmct.Button('',	focusTexture=K_S,	noFocusTexture=K)
        self.L_Button	= pyxbmct.Button('',	focusTexture=L_S,	noFocusTexture=L)
        self.M_Button	= pyxbmct.Button('',	focusTexture=M_S,	noFocusTexture=M)
        self.N_Button	= pyxbmct.Button('',	focusTexture=N_S,	noFocusTexture=N)
        self.O_Button	= pyxbmct.Button('',	focusTexture=O_S,	noFocusTexture=O)
        self.P_Button	= pyxbmct.Button('',	focusTexture=P_S,	noFocusTexture=P)
        self.Q_Button	= pyxbmct.Button('',	focusTexture=Q_S,	noFocusTexture=Q)
        self.R_Button	= pyxbmct.Button('',	focusTexture=R_S,	noFocusTexture=R)
        self.S_Button	= pyxbmct.Button('',	focusTexture=S_S,	noFocusTexture=S)
        self.T_Button	= pyxbmct.Button('',	focusTexture=T_S,	noFocusTexture=T)
        self.U_Button	= pyxbmct.Button('',	focusTexture=U_S,	noFocusTexture=U)
        self.V_Button	= pyxbmct.Button('',	focusTexture=V_S,	noFocusTexture=V)
        self.W_Button	= pyxbmct.Button('',	focusTexture=W_S,	noFocusTexture=W)
        self.X_Button	= pyxbmct.Button('',	focusTexture=X_S,	noFocusTexture=X)
        self.Y_Button	= pyxbmct.Button('',	focusTexture=Y_S,	noFocusTexture=Y)
        self.Z_Button	= pyxbmct.Button('',	focusTexture=Z_S,	noFocusTexture=Z)
        self.Guess_Button	= pyxbmct.Button('',	focusTexture=Guess_Focused,	noFocusTexture=Guess)
        self.Space_Button	= pyxbmct.Button('',	focusTexture=Space_Focused,	noFocusTexture=Space)

		
		#Place the Single Button Eliment in the Window
        self.placeControl(self.A_Button, 75, 1, 8, 2)
        self.placeControl(self.B_Button, 75, 3, 8, 2)
        self.placeControl(self.C_Button, 75, 5, 8, 2)
        self.placeControl(self.D_Button, 75, 7, 8, 2)
        self.placeControl(self.E_Button, 75, 9, 8, 2)
        self.placeControl(self.F_Button, 75, 11, 8, 2)
        self.placeControl(self.G_Button, 75, 13, 8, 2)
        self.placeControl(self.H_Button, 75, 15, 8, 2)
        self.placeControl(self.I_Button, 75, 17, 8, 2)
        self.placeControl(self.J_Button, 75, 19, 8, 2)
        self.placeControl(self.K_Button, 75, 21, 8, 2)
        self.placeControl(self.L_Button, 75, 23, 8, 2)
        self.placeControl(self.M_Button, 75, 25, 8, 2)
        self.placeControl(self.N_Button, 75, 27, 8, 2)
        self.placeControl(self.O_Button, 83, 1, 8, 2)
        self.placeControl(self.P_Button, 83, 3, 8, 2)
        self.placeControl(self.Q_Button, 83, 5, 8, 2)
        self.placeControl(self.R_Button, 83, 7, 8, 2)
        self.placeControl(self.S_Button, 83, 9, 8, 2)
        self.placeControl(self.T_Button, 83, 11, 8, 2)
        self.placeControl(self.U_Button, 91, 1, 8, 2)
        self.placeControl(self.V_Button, 91, 3, 8, 2)
        self.placeControl(self.W_Button, 91, 5, 8, 2)
        self.placeControl(self.X_Button, 91, 7, 8, 2)
        self.placeControl(self.Y_Button, 91, 9, 8, 2)
        self.placeControl(self.Z_Button, 91, 11, 8, 2)
        self.placeControl(self.Guess_Button, 83, 13, 8, 16)
        self.placeControl(self.Space_Button, 91, 13, 8, 16)


    def set_navigation(self):
		
		### TOP ROW RIGHT
        self.A_Button.controlRight(self.B_Button)
        self.B_Button.controlRight(self.C_Button)
        self.C_Button.controlRight(self.D_Button)
        self.D_Button.controlRight(self.E_Button)
        self.E_Button.controlRight(self.F_Button)
        self.F_Button.controlRight(self.G_Button)
        self.G_Button.controlRight(self.H_Button)
        self.H_Button.controlRight(self.I_Button)
        self.I_Button.controlRight(self.J_Button)
        self.J_Button.controlRight(self.K_Button)
        self.K_Button.controlRight(self.L_Button)
        self.L_Button.controlRight(self.M_Button)
        self.M_Button.controlRight(self.N_Button)
        self.N_Button.controlRight(self.A_Button)
		
		### TOP ROW LEFT
        self.A_Button.controlLeft(self.N_Button)
        self.B_Button.controlLeft(self.A_Button)
        self.C_Button.controlLeft(self.B_Button)
        self.D_Button.controlLeft(self.C_Button)
        self.E_Button.controlLeft(self.D_Button)
        self.F_Button.controlLeft(self.E_Button)
        self.G_Button.controlLeft(self.F_Button)
        self.H_Button.controlLeft(self.G_Button)
        self.I_Button.controlLeft(self.H_Button)
        self.J_Button.controlLeft(self.I_Button)
        self.K_Button.controlLeft(self.J_Button)
        self.L_Button.controlLeft(self.K_Button)
        self.M_Button.controlLeft(self.L_Button)
        self.N_Button.controlLeft(self.M_Button)
		
		### TOP ROW DOWN
        self.A_Button.controlDown(self.O_Button)
        self.B_Button.controlDown(self.P_Button)
        self.C_Button.controlDown(self.Q_Button)
        self.D_Button.controlDown(self.R_Button)
        self.E_Button.controlDown(self.S_Button)
        self.F_Button.controlDown(self.T_Button)
        self.G_Button.controlDown(self.Guess_Button)
        self.H_Button.controlDown(self.Guess_Button)
        self.I_Button.controlDown(self.Guess_Button)
        self.J_Button.controlDown(self.Guess_Button)
        self.K_Button.controlDown(self.Guess_Button)
        self.L_Button.controlDown(self.Guess_Button)
        self.M_Button.controlDown(self.Guess_Button)
        self.N_Button.controlDown(self.Guess_Button)
		
		### TOP ROW UP
        self.A_Button.controlUp(self.U_Button)
        self.B_Button.controlUp(self.V_Button)
        self.C_Button.controlUp(self.W_Button)
        self.D_Button.controlUp(self.X_Button)
        self.E_Button.controlUp(self.Y_Button)
        self.F_Button.controlUp(self.Z_Button)
        self.G_Button.controlUp(self.Guess_Button)
        self.H_Button.controlUp(self.Guess_Button)
        self.I_Button.controlUp(self.Guess_Button)
        self.J_Button.controlUp(self.Guess_Button)
        self.K_Button.controlUp(self.Guess_Button)
        self.L_Button.controlUp(self.Guess_Button)
        self.M_Button.controlUp(self.Guess_Button)
        self.N_Button.controlUp(self.Guess_Button)
		
		### SECOND ROW RIGHT
        self.O_Button.controlRight(self.P_Button)
        self.P_Button.controlRight(self.Q_Button)
        self.Q_Button.controlRight(self.R_Button)
        self.R_Button.controlRight(self.S_Button)
        self.S_Button.controlRight(self.T_Button)
        self.T_Button.controlRight(self.Guess_Button)
        self.Guess_Button.controlRight(self.O_Button)
		
		#### SECOND ROW LEFT
        self.Guess_Button.controlLeft(self.T_Button)
        self.T_Button.controlLeft(self.S_Button)
        self.S_Button.controlLeft(self.R_Button)
        self.R_Button.controlLeft(self.Q_Button)
        self.Q_Button.controlLeft(self.P_Button)
        self.P_Button.controlLeft(self.O_Button)
        self.O_Button.controlLeft(self.Guess_Button)

        #### SECOND ROW UP
        self.O_Button.controlUp(self.A_Button)
        self.P_Button.controlUp(self.B_Button)
        self.Q_Button.controlUp(self.C_Button)
        self.R_Button.controlUp(self.D_Button)
        self.S_Button.controlUp(self.E_Button)
        self.T_Button.controlUp(self.F_Button)
        self.Guess_Button.controlUp(self.N_Button)
		
        #### SECOND ROW DOWN
        self.O_Button.controlDown(self.U_Button)
        self.P_Button.controlDown(self.V_Button)
        self.Q_Button.controlDown(self.W_Button)
        self.R_Button.controlDown(self.X_Button)
        self.S_Button.controlDown(self.Y_Button)
        self.T_Button.controlDown(self.Z_Button)
        self.Guess_Button.controlDown(self.Space_Button)
		
        #### BOTTOM ROW DOWN
        self.U_Button.controlDown(self.A_Button)
        self.V_Button.controlDown(self.B_Button)
        self.W_Button.controlDown(self.C_Button)
        self.X_Button.controlDown(self.D_Button)
        self.Y_Button.controlDown(self.E_Button)
        self.Z_Button.controlDown(self.F_Button)
		
        #### BOTTOM ROW UP
        self.U_Button.controlUp(self.O_Button)
        self.V_Button.controlUp(self.P_Button)
        self.W_Button.controlUp(self.Q_Button)
        self.X_Button.controlUp(self.R_Button)
        self.Y_Button.controlUp(self.S_Button)
        self.Z_Button.controlUp(self.T_Button)
        self.Space_Button.controlUp(self.Guess_Button)
		
        #### BOTTOM ROW RIGHT
        self.U_Button.controlRight(self.V_Button)
        self.V_Button.controlRight(self.W_Button)
        self.W_Button.controlRight(self.X_Button)
        self.X_Button.controlRight(self.Y_Button)
        self.Y_Button.controlRight(self.Z_Button)
        self.Z_Button.controlRight(self.Space_Button)
        self.Space_Button.controlRight(self.U_Button)
		
        #### BOTTOM ROW LEFT
        self.U_Button.controlLeft(self.Space_Button)
        self.V_Button.controlLeft(self.U_Button)
        self.W_Button.controlLeft(self.V_Button)
        self.X_Button.controlLeft(self.W_Button)
        self.Y_Button.controlLeft(self.X_Button)
        self.Z_Button.controlLeft(self.Y_Button)
        self.Space_Button.controlLeft(self.Z_Button)