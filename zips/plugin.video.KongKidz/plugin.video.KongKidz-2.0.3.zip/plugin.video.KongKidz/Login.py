#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import time
import urllib
import urllib2
import urlparse
import Main

import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon

#############################################################
#################### SET ADDON ID ###########################
_addon_id_	= 'plugin.video.KongKidz'
_self_			= xbmcaddon.Addon(id=_addon_id_)

#############################################################
#################### SET ADDON THEME DIRECTORY ##############
_theme_			= _self_.getSetting('Theme')
_images_		= '/resources/' + _theme_	

#############################################################
#################### SET ADDON THEME IMAGES #################
Background_Image	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, '1.png'))
UnFocus_Image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 't1.png'))
Focused_image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 't2.png'))
ButtonF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'g2.png'))
ButtonNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'g1.png'))
User_Image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'username.png'))

#############################################################
########## Function To Call That Starts The Window ##########
def LoginWindow():
    window = Login('KongKidz')
    window.doModal()
    del window
	
def SAVE(self):
	
	_self_.setSetting('Username', self.username.getText())
	Main.MainWindow()

#############################################################
######### Class Containing the GUi Code / Controls ##########
class Login(pyxbmct.AddonFullWindow):

    xbmc.executebuiltin("Dialog.Close(busydialog)")

    def __init__(self, title='KongKidz'):
        super(Login, self).__init__(title)
		
		#set the location and size of your window in kodi
        self.setGeometry(1280, 720, 100, 50)
		
		## Set The backGround Image using PYX Image
        Background			= pyxbmct.Image(Background_Image)
		
		## Place The BackGround Image (X, Y, W, H)
        self.placeControl(Background, -9, -1, 121, 52)
		
        User_img	= pyxbmct.Image(User_Image)
        self.placeControl(User_img, 50, 17, 7, 5)
		
		## function to set information controls none interactive
        self.set_info_controls()
		
		## function to set active controls that users interact with 
        self.set_active_controls()
		
		## function to set what happens when users press left,right,up,down on your active controls
        self.set_navigation()
		
		## connect the back button to pyx to close window
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)


    def set_info_controls(self):
	
		## create and place a static information able control
        self.username =	pyxbmct.Edit('', textColor='#000000', focusTexture=Focused_image, noFocusTexture=UnFocus_Image, isPassword=False)
        self.placeControl(self.username, 46, 16, 7, 15)

    def set_active_controls(self):
		
		#Create a single Button Eliment
        self.go	= pyxbmct.Button('',	focusTexture=ButtonF,	noFocusTexture=ButtonNF)
		
		#Place the Single Button Eliment in the Window
        self.placeControl(self.go, 43, 31, 12, 3)
		
		# connect your button to a function or a predefined pyx function
        self.connect(self.go, lambda:SAVE(self))


    def set_navigation(self):
		
		#set the navigation for if user presses Right when eliment if focused
        self.username.controlRight(self.go)
		
		#set the navigation for if user presses left when eliment if focused
        self.go.controlLeft(self.username)
		
		#Set the focuse on the eliment you want select on Window Start
        self.setFocus(self.username)