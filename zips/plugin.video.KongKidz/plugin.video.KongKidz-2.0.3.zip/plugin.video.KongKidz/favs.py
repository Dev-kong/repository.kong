import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import sqlite3

_addon_id_	= 'plugin.video.KongKidz'
_self_			= xbmcaddon.Addon(id=_addon_id_)
_addon_folder_ = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_))

databases = xbmc.translatePath(os.path.join(_addon_folder_, 'databases'))
favoritesdb = xbmc.translatePath(os.path.join(databases, 'favorites.db'))

if ( not os.path.exists(databases)): os.makedirs(databases)

conn = sqlite3.connect(favoritesdb)
c = conn.cursor()
try:
    c.executescript("CREATE TABLE IF NOT EXISTS favorites (name, url, img, desc);")
except:
    pass
conn.close()

def Favorites(fav,name,url,img,desc):
    if fav == "add":
        delFav(url)
        addFav(name, url, img, desc)
        return name + ' Added to Favorites'
    elif fav == "del":
        delFav(url)
        return name + ' Removed from Favorites'


def addFav(name,url,img,desc):
    conn = sqlite3.connect(favoritesdb)
    conn.text_factory = str
    c = conn.cursor()
    c.execute("INSERT INTO favorites VALUES (?,?,?,?)", (name, url, img, desc))
    conn.commit()
    conn.close()


def delFav(url):
    conn = sqlite3.connect(favoritesdb)
    c = conn.cursor()
    c.execute("DELETE FROM favorites WHERE url = '%s'" % url)
    conn.commit()
    conn.close()