# -*- coding: utf-8 -*-
#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import time
import json
import urllib
import random
import base64
import urllib2
import urlparse
import time
import threading
import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon
import base64
import xml.etree.ElementTree as ET

#############################################################
#################### SET ADDON ID ###########################
_addon_id_	= 'plugin.video.Xports'
_self_		= xbmcaddon.Addon(id=_addon_id_)
addon		= Addon(_addon_id_, sys.argv)

#SET THE DEFAULT FOLDER FOR SKIN IMAGES
_images_	= '/resources/Red/'

#SET DIALOG TO = XBMCGUI DIALOG FUNCTION
Dialog = xbmcgui.Dialog()

#GET THE CURRENT DATE IN D/M FORMAT
Date = time.strftime("%d/%m")

#GET SOME NEEDED INFORMATION FROM ADDON SETTINGS

_BASE_ = 'http://'+_self_.getSetting('Server')
_PORT_ = _self_.getSetting('Port')
_USERNAME_ = _self_.getSetting('Username')
_PASSWORD_ = _self_.getSetting('Password')
pvrsettings	= xbmc.translatePath(os.path.join('special://home/userdata/addon_data/pvr.iptvsimple/settings.xml'))

text_test = 'bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb'

#############################################################
#################### SET ADDON THEME IMAGES #################
Icon			= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_, 'Icon.png'))
FanArt			= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_, 'Fanart.png'))
Background_Image	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'Background.png'))
Vert_Image		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'vertical.png'))
Hori_Image		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'horizontal.png'))
Header_bg		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'header-back.png'))
Nav_bg			= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'nav.png'))
Guide_img		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'tv-guide.png'))
Guide_img_selected		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'tv-guide-selected.png'))
Logo_img		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'logo-settings.png'))
Focused_Button	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'nav-selected.png'))
List_bg			= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'list-bg.png'))
List_Focused	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'list-bg-selected.png'))
Test_Icon		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'ch-icon.png'))
Arrow_Image		= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'arrow.png'))

def run():
	#CREATE AND LOAD THE MAIN ADDON WINDOWS
	
	if _USERNAME_ =='' or _PASSWORD_ == '' or _BASE_ == '' or _PORT_ == '':
		Dialog.ok('XPORTS','There Seems To Be Some Information Missing From Your Account Settings Please Double Check You Have Entered Everything.')
		_self_.openSettings()
		Dialog.ok('XPORTS','If Everything Looks Ok Please Try Opening The Addon Again Or Contact Support.')
	else:
		window = Main('Xports')
		window.doModal()
		del window
		
def PLAY(self):	
	Link_name = CH_Title
	Link_Image  =	CH_Logo
	Link = CH_Stream
	Show_List	=	xbmcgui.ListItem(Link_name, iconImage=Link_Image,thumbnailImage=Link_Image)
	xbmc.Player().play(Link, Show_List, False)
	
def pvr(self):

			set = open(pvrsettings).read().replace('\n', '').replace('\r','').replace('\t','')
			check = re.compile ('<setting id="epgUrl" value="(.*?)" \/>').findall(set)[0]
			if len(check) <= 1:
				jsonSetPVR = '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.enabled", "value":true},"id":1}'
				IPTVon 	   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.iptvsimple","enabled":true},"id":1}'
				nulldemo   = '{"jsonrpc":"2.0","method":"Addons.SetAddonEnabled","params":{"addonid":"pvr.demo","enabled":false},"id":1}'
				loginurl   = "http://xports.ddns.net:25461/get.php?username=" + _USERNAME_ + "&password=" + _PASSWORD_ + "&type=m3u_plus&output=ts"
				EPGurl     = "http://xports.tv/epg.xml.gz"

				xbmc.executeJSONRPC(jsonSetPVR)
				xbmc.executeJSONRPC(IPTVon)
				xbmc.executeJSONRPC(nulldemo)

				sexyaddon = xbmcaddon.Addon('pvr.iptvsimple')
				sexyaddon.setSetting(id='m3uUrl', value=loginurl)
				sexyaddon.setSetting(id='epgUrl', value=EPGurl)
				sexyaddon.setSetting(id='m3uCache', value="false")
				sexyaddon.setSetting(id='epgCache', value="false")
				Dialog.ok("Xsports","PVR Client Updated, Please restart kodi for changes to take effect")
			else:
				xbmc.executebuiltin('RunPlugin(10609)')
				self.close()
	
def tick(self):
	
	# UPDATE THE CURRENT TIME AND UPDATE THE CURRENT DATE
	# get the current local time from the PC
	time2 = time.strftime("%I:%M %p")
	self.DATE.setLabel("Today " + str(Date))
	self.TIME.setLabel(str(time2))	
	
def Get_Data(URL):

	# USE URLLIB2 FOR ALL WEB REQUESTS WITH THE MOZILLA USER AGENT
    req = urllib2.Request(URL)
    req.add_header(
        'User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36')
    response = urllib2.urlopen(req, timeout=30)
    data = response.read()
    response.close()

    return data
	
def find_single_match(text,pattern):

	# USE RE TO FIND THE PATTERN THAT IS A SINGLE MATCH TO OUR REGEX
    result = ""
    try:    
        matches = re.findall(pattern,text, flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""

    return result
	
def find_multiple_matches(text,pattern):
    
	# USE RE TO FIND ALL PATTERNS THAT MATCH OUT REGEX
    matches = re.findall(pattern,text,re.DOTALL)

    return matches
	
def Get_Live(self, CHID):

	#CREATE THE SERVER URL FROM MULTIPUL PARTS AND THEN CONNECT THE SERVER URL TO CHANNELS URL ELIMENTS TO CREATE FULL URL
	server_url = _BASE_ + ':' + _PORT_
	channels_url = server_url + '/enigma2.php?username=' + _USERNAME_ + '&password=' + _PASSWORD_ + '&type=get_live_streams&cat_id=' + CHID

	# SET THE GLOBAL VERIABLES THAT WILL BE USED IN THE ADDON
	# FOR CHANNEL INFORMATION AND LIST BOXES
	global Channel_Title
	global Channel_Logo
	global Channel_Now
	global Channel_Next
	global Channel_Now_Desc
	global Channel_Next_Desc
	global Channel_Stream

	#RESET OUT LISTS BACK TOP EMPTY SHOULD SOMETHING GLITCH
	self.LIST.reset()
	self.EPG1.reset()
	self.EPG2.reset()
	#MAKE SURE OUT LIST IS STILL SET TO VISIBLE
	self.LIST.setVisible(True)
	self.EPG1.setVisible(True)
	self.EPG2.setVisible(True)
	
	# CREATE THE ARRAYS THAT WILL HOLD OUR CHANNEL INFORMATION
	# THESE SHOULD MATCH YOUR GLOBAL VERIABLES
	Channel_Title		= []
	Channel_Logo		= []
	Channel_Now			= []
	Channel_Next		= []
	Channel_Now_Desc	= []
	Channel_Next_Desc	= []
	Channel_Stream		= []
	
	#GRAB THE CHANNEL INFORMATION
	Data = Get_Data(channels_url)
	
	#CREATE AN XML TREE FROM A LOADED STRING
	tree = ET.ElementTree(ET.fromstring(Data))
	
	#GET THE ROOT TAG OF THE XML WITCH IS ITEMS
	root = tree.getroot()

	#FOR EVERY CHANNEL TAG FOUND IN XML
	for channel in root.findall('channel'):

		#GRAB THE NEEDED CHANNEL TAGES FROM XML
		Title_Tag  = channel.find('title').text
		Desc_Tag  = channel.find('description').text
		Logo_Tag = channel.find('desc_image').text
		Stream_Tag  = channel.find('stream_url').text
		Category_Tag = channel.find('category_id').text
		
		# BASE64 DECODE THE TITLE AND DESCRIPTION TAGS
		Title_Decoded_raw = base64.b64decode(str(Title_Tag))
		Desc_Decoded_raw = base64.b64decode(str(Desc_Tag))
		
		# AD A HASH TO THE START AND END OF THE DECODED TAGS TO MAKE REGEX EASIER
		Title_Decoded = '#' + Title_Decoded_raw + '#'
		Desc_Decoded = '#' + Desc_Decoded_raw + '#'
		

		# CHECK TO SEE IF THE CHANNEL HAS A LOGO IF NOT USE A PLAIN ICON OF A TV
		if Logo_Tag == '' or Logo_Tag is None:
			Data_Channel_Logo = 'https://findicons.com/files/icons/2772/modern_ui/76/appbar_tv.png'
		else:
			Data_Channel_Logo = Logo_Tag
		
		# CHECK IF THE CHANNEL HAS A DESCRIPTION IF IT DOSE NOT USE DEFAULT INFORMATION
		if '[' in Desc_Decoded:
			Desc_Regex = '\[(.*?)\]\s(.*?)\s+\(\s+(.*?)\)\s+\[(.*?)\]\s(.*?)\s+\(\s+(.*?)\)'
			Data_Channel_Now = find_single_match(Desc_Decoded, Desc_Regex)[1]
			Data_Channel_Next = find_single_match(Desc_Decoded, Desc_Regex)[4]
			Data_Channel_Now_Desc = find_single_match(Desc_Decoded, Desc_Regex)[2]
			Data_Channel_Next_Desc = find_single_match(Desc_Decoded, Desc_Regex)[5]

		else:	
			Data_Channel_Now = 'No EPG Information Found!'
			Data_Channel_Next = 'No EPG Information Found!'
			Data_Channel_Now_Desc = 'No Information Is Avalable For This Channel In Our EPG DataBase.'
			Data_Channel_Next_Desc = 'No Information Is Avalable For This Channel In Our EPG DataBase.'
		
		# IF THERE IS A SQUARE BRACKERT [] THEN IT CONTAINS NOW PLAYING INFORMATION
		# WE DONT NEEX THIS SO REGEX IT OUT AND JUST GRAB THE CHANNEL NAME
		if "[" in Title_Decoded:
			Title_Regex = '#(.*?)\:\s(.*?)\s\[(.*?)\]\s(.*?)\s+min\s+(.*?)#'
			Data_Channel_Title = find_single_match(Title_Decoded, Title_Regex)[1].replace('HD',' [HD] ').replace('FHD',' [FHD] ')
		else:
			Title_Regex = '#(.*?):\s+(.*?)#'
			Data_Channel_Title = find_single_match(Title_Decoded, Title_Regex)[1].replace('HD',' [HD] ').replace('FHD',' [FHD] ')
		
		# ADD THE INFORMATION WE HAVE TO THE ARRAYS WE CREATED
		Channel_Title.append(Data_Channel_Title)
		Channel_Logo.append(Data_Channel_Logo)
		Channel_Now.append(Data_Channel_Now)
		Channel_Next.append(Data_Channel_Next)
		Channel_Now_Desc.append(Data_Channel_Now_Desc)
		Channel_Next_Desc.append(Data_Channel_Next_Desc)
		Channel_Stream.append(Stream_Tag)
		
		#ADD THE CHANNEL TITLE NOW AND NEXT TO EACH LIST BOX
		self.LIST.addItem(Data_Channel_Title)
		self.EPG1.addItem(Data_Channel_Now)
		self.EPG2.addItem(Data_Channel_Next)



#############################################################
######### Class Containing the GUi Code / Controls ##########
class Main(pyxbmct.AddonFullWindow):

	#CLOSE THE BUSY SPINNER THAT ALL WAYS APPEARS USING PYXBMCT
	xbmc.executebuiltin("Dialog.Close(busydialog)")

	def __init__(self, title='Xports'):
		super(Main, self).__init__(title)
		
		#SET THE STARTING LOCATION AND SIZE OF THE ADDON WINDOW
		self.setGeometry(1280, 720, 111, 52)
		
		## SET THE ADDON BACKGROUND IMAGE AND HEADER AND NAV WITH PYXBMCT.IMAGE
		Background = pyxbmct.Image(Background_Image)
		Header = pyxbmct.Image(Header_bg)
		Nav = pyxbmct.Image(Nav_bg)
		
		## PLACE THE IMAGES ON SCREEN USING (X, Y, H, W)
		self.placeControl(Background, -9, -1, 140, 56)
		self.placeControl(Header, -11, -1, 12, 56)
		self.placeControl(Nav, -1, -1, 12, 56)
		
		## SET THE INFORMATION CONTROL THAT THE ADDON USES USUALY NO INTERACTIVE ELIMENTS
		self.set_info_controls()
		
		## SET THE ACTIVE CONTROL THAT USERS CAN CLICK OR CHANGE
		self.set_active_controls()
		
		## SET THE NAVIGATION BETWEEN INTERACTIVE CONTROLS UP, DOWN, LEFT AND RIGHT
		self.set_navigation()
		
		# SET THE LOGO FOR THE ADDON THIS IS PLACED HERSO ITS ABOVE THE BACKGROUND IMAGE
		Logo = pyxbmct.Image(Logo_img)
		self.placeControl(Logo, -11, -1, 12, 15)
		
		## SET THE CONNECTION EVEN THAT CALLS FUNCTIONS WHEN ACTIVE CONTROLS ARE PRESSED
		self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
		self.connect(self.USA, lambda:Get_Live(self,'3'))
		self.connect(self.UK, lambda:Get_Live(self,'10'))
		self.connect(self.CAN, lambda:Get_Live(self,'5'))
		self.connect(self.NBA, lambda:Get_Live(self,'6'))
		self.connect(self.PPV, lambda:Get_Live(self,'6'))
		self.connect(self.VOD, lambda:Get_Live(self,'6'))
		self.connect(self.GUIDE, lambda:pvr(self))
		self.connect(self.LIST, lambda:PLAY(self))
		
		#CALL THE FUNCTION THAT FIRST UPDATES THE TIME AND DATE
		tick(self)
		#SET FOCUSE TO ONE OF THE NAV ACTIVE ELIMENTS TO ALLOW USERS WITH REMOTES TO USE THE ADDON
		self.setFocus(self.VOD)

	def set_info_controls(self):
		
		#SET THE PYXBMCT LABLES THAT DISPLAY TEXT ON SCREEN
		self.TIME			=	pyxbmct.Label('',textColor='0xFFA09F9F', font='font14')
		self.DATE			=	pyxbmct.Label('',textColor='0xFFFFFFFF')
		self.EPGNOW			=	pyxbmct.Label('Name',textColor='0xFFFFFFFF')
		self.EPGNEXT		=	pyxbmct.Label('Now',textColor='0xFFFFFFFF')
		self.EPGLATER		=	pyxbmct.Label('Next',textColor='0xFFFFFFFF')
		self.DESCRIPTION	=	pyxbmct.TextBox()
		
		#SIMPLE PLACE TO ENTER THE CHANNELS ICON FOR DISPLAYING IN THE FOOTER
		self.CHANNEL_LOGO_FOOTER	=	pyxbmct.Image('')
		

		#PLACE THE PYXBMCT LABLES THAT DISPLAY TEXT ON SCREEN USING X, Y, H, W
		self.placeControl(self.DATE,  13, 1, 12, 15)
		self.placeControl(self.TIME,  -9, 48, 12, 15)
		self.placeControl(self.EPGNOW,  14, 7, 10,4)
		self.placeControl(self.EPGNEXT,  14, 21, 10,4)
		self.placeControl(self.EPGLATER, 14, 35, 10,4)
		self.placeControl(self.DESCRIPTION, 107, 8, 20,50)
		#PLACE THE PYXBMCT IMAGE THAT DISPLAYS THE CHANNELS LOGO IN FOOTER WITH X, Y, H, W
		self.placeControl(self.CHANNEL_LOGO_FOOTER, 107, 0, 19, 5)

	def set_active_controls(self):
		
		##SET THE PYXBMCT BUTTONS THAT USERS INTERACT WITH
		self.GUIDE	=	pyxbmct.Button('',	focusTexture=Guide_img_selected, noFocusTexture=Guide_img)
		self.VOD	=	pyxbmct.Button(' VOD ',	focusTexture=Focused_Button, noFocusTexture="", textColor='0xFF3E4349', focusedColor='0xFF3E4349')
		self.PPV	=	pyxbmct.Button(' PPV ',	focusTexture=Focused_Button, noFocusTexture="", textColor='0xFF3E4349', focusedColor='0xFF3E4349')
		self.USA	=	pyxbmct.Button(' USA ',	focusTexture=Focused_Button, noFocusTexture="", textColor='0xFF3E4349', focusedColor='0xFF3E4349')
		self.UK		=	pyxbmct.Button(' UK ',	focusTexture=Focused_Button, noFocusTexture="", textColor='0xFF3E4349', focusedColor='0xFF3E4349')
		self.CAN	=	pyxbmct.Button(' CAN ',	focusTexture=Focused_Button, noFocusTexture="", textColor='0xFF3E4349', focusedColor='0xFF3E4349')
		self.NBA	=	pyxbmct.Button(' NBA ',	focusTexture=Focused_Button, noFocusTexture="", textColor='0xFF3E4349', focusedColor='0xFF3E4349')
		self.LIST	=	pyxbmct.List(buttonFocusTexture=List_Focused, buttonTexture=List_bg, _imageWidth=90, _imageHeight=90, _space=-1, _itemHeight=80,  _itemTextXOffset=30, _itemTextYOffset=-2, textColor='0xFFFFFFFF')
		self.EPG1	=	pyxbmct.List(buttonFocusTexture=List_Focused, buttonTexture=List_bg, _space=-1, _itemHeight=80,  _itemTextXOffset=10, _itemTextYOffset=-2, textColor='0xFFFFFFFF')
		self.EPG2	=	pyxbmct.List(buttonFocusTexture=List_Focused, buttonTexture=List_bg, _space=-1, _itemHeight=80,  _itemTextXOffset=10, _itemTextYOffset=-2, textColor='0xFFFFFFFF')
		
		#PLACE THE PYXBMCT BUTTONS THAT DISPLAY TEXT ON SCREEN USING X, Y, H, W
		self.placeControl(self.USA, -1, -1, 12, 5)
		self.placeControl(self.UK, -1, 3, 12, 5)
		self.placeControl(self.CAN, -1, 7, 12, 5)
		self.placeControl(self.NBA, -1, 11, 12, 5)
		self.placeControl(self.PPV, -1, 15, 12, 5)
		self.placeControl(self.VOD, -1, 19, 12, 5)
		self.placeControl(self.GUIDE, -11, 12, 12, 9)
		self.placeControl(self.EPG2, 21, 34, 90, 20)
		self.placeControl(self.EPG1, 21, 20, 90, 15)
		self.placeControl(self.LIST, 21, 0, 90, 21)
		
		##THERE IMAGES ARE PLACED HERE TO MAKE SURE THEY DISPLAY ABOVE OTHER ELIMENTS
		Vert = pyxbmct.Image(Vert_Image)
		Hori = pyxbmct.Image(Hori_Image)
		Hori1 = pyxbmct.Image(Hori_Image)
		Hori2 = pyxbmct.Image(Hori_Image)
		Hori3 = pyxbmct.Image(Hori_Image)
		Hori4 = pyxbmct.Image(Hori_Image)
		Hori5 = pyxbmct.Image(Hori_Image)
		self.Arrow = pyxbmct.Image(Arrow_Image)
		self.Arrow1 = pyxbmct.Image(Arrow_Image)
		self.Arrow2 = pyxbmct.Image(Arrow_Image)
		
		#PLACE THE PYXBMCT IMAGES THAT DISPLAY TEXT ON SCREEN USING X, Y, H, W
		self.placeControl(Vert, 21, 6, 90,5)
		self.placeControl(Hori, 100, 0, 5,60)
		self.placeControl(Hori1, 84, 0, 5,60)
		self.placeControl(Hori2, 69, 0, 5,60)
		self.placeControl(Hori3, 53, 0, 5,60)
		self.placeControl(Hori4, 37, 0, 5,60)
		self.placeControl(Hori5, 21, 0, 5,60)
		self.placeControl(self.Arrow, 13, 6, 10,4)
		self.placeControl(self.Arrow1, 13, 20, 10,4)
		self.placeControl(self.Arrow2, 13, 34, 10,4)
		
		#CALL FUNCTION TO GET LIVE CHANNEL LIST AND EPG INFORMATION
		Get_Live(self, '3')
		#SET THE BLUE ARROWS FOR NOW AND NEXT TO VISABLE = FALSE TO HIDE THEM ON START UP
		self.Arrow1.setVisible(False)
		self.Arrow2.setVisible(False)
		
		#SET UP THE CONTROL LISTENER FOR MOUSE AND BUTTON CLICKS TO UPDATE LISTS
		self.connectEventList(
			[pyxbmct.ACTION_MOVE_DOWN,
			pyxbmct.ACTION_MOVE_UP,
			pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
			pyxbmct.ACTION_MOUSE_WHEEL_UP,
			pyxbmct.ACTION_MOUSE_MOVE],
			self.Multi_Update)
		
	def set_navigation(self):
	
		#CREATE THE NAVIGATION CONNECTIONS FOR UP, DOWN, LEFT, RIGHT
		self.VOD.controlRight(self.USA)
		self.VOD.controlLeft(self.PPV)
		self.VOD.controlUp(self.GUIDE)
		self.VOD.controlDown(self.LIST)
		self.PPV.controlRight(self.VOD)
		self.PPV.controlLeft(self.NBA)
		self.PPV.controlUp(self.GUIDE)
		self.PPV.controlDown(self.LIST)
		self.USA.controlRight(self.UK)
		self.USA.controlLeft(self.VOD)
		self.USA.controlUp(self.GUIDE)
		self.USA.controlDown(self.LIST)
		self.UK.controlRight(self.CAN)
		self.UK.controlLeft(self.USA)
		self.UK.controlUp(self.GUIDE)
		self.UK.controlDown(self.LIST)
		self.CAN.controlRight(self.NBA)
		self.CAN.controlLeft(self.UK)
		self.CAN.controlUp(self.GUIDE)
		self.CAN.controlDown(self.LIST)
		self.NBA.controlRight(self.PPV)
		self.NBA.controlLeft(self.CAN)
		self.NBA.controlUp(self.GUIDE)
		self.NBA.controlDown(self.LIST)
		self.GUIDE.controlDown(self.USA)
		self.LIST.controlUp(self.USA)
		self.LIST.controlRight(self.EPG1)
		self.EPG1.controlLeft(self.LIST)
		self.EPG1.controlRight(self.EPG2)
		self.EPG2.controlLeft(self.EPG1)
		
		
	def Multi_Update(self):
	
		# RUN FUNCTION TO UPDATE TIME AND DATE
		tick(self)
		#UPDATE THE LIST BASSED ON SELECTION
		self.list_update()
		
	def list_update(self):
	
		#SET THE GLOBALS USED FOR MEDIA INFORMATION TO UPDATE OTHER WINDOW
		#ELIMENTS WHEN LIST IS UPDATED
		global CH_Title
		global CH_Logo
		global CH_Now
		global CH_Next
		global CH_Desc
		global CH_Stream
		global CH_Position

		#TRY TO DETERMIN WHAT LIST IS FOCUSED TO UPDATE ELIMENTS APPROPRIATLY
		try:
			#IF THE MAIN LIST IF FOCUSEDRUN THE FOLLOWING CODE
			if self.getFocus() == self.LIST:
			
				CH_Position =	self.LIST.getSelectedPosition()
				self.Arrow.setVisible(True)
				self.Arrow1.setVisible(False)
				self.Arrow2.setVisible(False)
			
				self.EPG1.selectItem(CH_Position)
				self.EPG2.selectItem(CH_Position)
				CH_Desc =  Channel_Now_Desc[CH_Position]
				CH_Logo		=	Channel_Logo[CH_Position]
			#IF THE NOW EPG LIST IS FOCUSED RUN THE FOLLOWING CODE	
			elif self.getFocus() == self.EPG1:
			
				CH_Position =	self.EPG1.getSelectedPosition()		
				self.Arrow.setVisible(False)
				self.Arrow1.setVisible(True)
				self.Arrow2.setVisible(False)
			
				self.LIST.selectItem(CH_Position)
				self.EPG2.selectItem(CH_Position)
				CH_Desc =  Channel_Now_Desc[CH_Position]
				CH_Logo	= Channel_Logo[CH_Position-1]
			#IF THE NEX EPG LIST IS FOCUSED RUN THE FOLLOWING CODE
			elif self.getFocus() == self.EPG2:
			
				CH_Position =	self.EPG2.getSelectedPosition()
				self.Arrow2.setVisible(True)
				self.Arrow1.setVisible(False)
				self.Arrow.setVisible(False)
			
				self.EPG1.selectItem(CH_Position)
				self.LIST.selectItem(CH_Position)
				CH_Desc =  Channel_Next_Desc[CH_Position]
				self.LIST.getSelectedItem().setIconImage(CH_Logo)
				CH_Logo	= Channel_Logo[CH_Position-1]
			
			#SET THE CHANNEL TITLE, LOGO DESCRIPTION BASSED ON THE POSITION OF LIST ONE
			CH_Title	=	Channel_Title[CH_Position] + ' : ' + Channel_Now[CH_Position]
			CH_Stream	=	Channel_Stream[CH_Position]
			self.LIST.getSelectedItem().setIconImage(CH_Logo)
			
			self.DESCRIPTION.setText(CH_Desc)
			self.CHANNEL_LOGO_FOOTER.setImage(CH_Logo)
			
			# Set auto-scrolling for long TexBox contents
			self.DESCRIPTION.autoScroll(1000, 1000, 1000)


		except (RuntimeError, SystemError):
			pass


run()