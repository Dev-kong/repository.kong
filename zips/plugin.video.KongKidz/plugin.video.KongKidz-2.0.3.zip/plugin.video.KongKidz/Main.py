#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import urllib
import urllib2
import urlparse
import Shows
import Movies
import Live
import Favorites

import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon


#############################################################
#################### SET ADDON ID ###########################
_addon_id_	= 'plugin.video.KongKidz'
_self_			= xbmcaddon.Addon(id=_addon_id_)

#############################################################
#################### SET ADDON THEME DIRECTORY ##############
_theme_			= _self_.getSetting('Theme')
_images_		= '/resources/' + _theme_	
username 		= _self_.getSetting('Username')
_baseURL_       = 'https://www.watchcartoononline.io/cartoon-list'

#############################################################
#################### SET ADDON THEME IMAGES #################
Background_Image	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, '2.png'))
UnFocus_Image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 't1.png'))
Focused_image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 't2.png'))
ButtonF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'b2.png'))
ButtonNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'b1.png'))
SettingsF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'S2.png'))
SettingsNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'S1.png'))
HomeF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'h2.png'))
HomeNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'h1.png'))
##SearchF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 's2.png'))
##SearchNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 's1.png'))
List_Focused = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'listf.png'))

#############################################################
########## Function To Call That Starts The Window ##########
def MainWindow():

    global List
	
    window = Main('KongKidz')
    window.doModal()
    del window
	
def Get_Data(url):

    req = urllib2.Request(url)
    req.add_header(
        'User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36')
    response = urllib2.urlopen(req, timeout=30)
    data = response.read()
    response.close()

    return data
	
def Get_Shows(self):

	self.List.reset()
	self.List.setVisible(True)
	self.List.addItem('**** MAIN MENU ****')

##########################: SET GLOBALS
	global show_one
	global show_two
	global show_three
	global show_four
	
	show_one	=	[]
	show_two	=	[]
	show_three	=	[]
	show_four	=	[]
	
	Live_Title	= 'KongKidz Live TV'
	Live_Desc	= 'Watch Public Kids TV Channels on KongKidz'
	show_one.append(Live_Title)
	show_two.append(':LIVE:')
	show_three.append(Live_Desc)
	show_four.append('http://via.placeholder.com/300x220/13b7ff/FFFFFF?text=' + Live_Title)
	self.List.addItem(Live_Title)

	Shows_Title		= 'KongKidz Cartoons'
	Shows_Desc		= 'Watch Popular Kids Cartoons on KongKidz'
	show_one.append(Shows_Title)
	show_two.append(':SHOWS:')
	show_three.append(Shows_Desc)
	show_four.append('http://via.placeholder.com/300x220/13b7ff/FFFFFF?text=' + Shows_Title)
	self.List.addItem(Shows_Title)
		
	Movies_Title	= 'KongKidz Movies'
	Movies_Desc		= 'Watch Popular Kids Movies on KongKidz'
	show_one.append(Movies_Title)
	show_two.append(':MOVIES:')
	show_three.append(Movies_Desc)
	show_four.append('http://via.placeholder.com/300x220/13b7ff/FFFFFF?text=' + Movies_Title)
	self.List.addItem(Movies_Title)
	
	Classic_Title	= 'KongKidz Favorites'
	Classic_Desc	= 'Find all you KongKidz Favorites here'
	show_one.append(Classic_Title)
	show_two.append(':FAV:')
	show_three.append(Classic_Desc)
	show_four.append('http://via.placeholder.com/300x220/13b7ff/FFFFFF?text=' + Classic_Title)
	self.List.addItem(Classic_Title)
		
#####
def List_Selected(self):

	if ":SHOWS:" in media_url:
		Shows.ShowsWindow()
			
	elif ':MOVIES:' in media_url:
		Movies.MoviesWindow()
		
	elif ':LIVE:' in media_url:
		Live.LiveWindow()
	elif ':FAV:' in media_url:
		Favorites.FAVWindow()
			
def Return_Home(self):

		self.List.reset()
		self.List.setVisible(True)
		Get_Shows(self)

			
#############################################################
######### Class Containing the GUi Code / Controls ##########
class Main(pyxbmct.AddonFullWindow):

    xbmc.executebuiltin("Dialog.Close(busydialog)")

    def __init__(self, title='KongKidz'):
        super(Main, self).__init__(title)
		
		#set the location and size of your window in kodi
        self.setGeometry(1280, 720, 100, 50)
		
		## Set The backGround Image using PYX Image
        Background			= pyxbmct.Image(Background_Image)
		
		## Place The BackGround Image (X, Y, W, H)
        self.placeControl(Background, -10, -1, 123, 52)
		
		## function to set information controls none interactive
        self.set_info_controls()
		
		## function to set active controls that users interact with 
        self.set_active_controls()
		
		## function to set what happens when users press left,right,up,down on your active controls
        self.set_navigation()
		
		## connect the back button to pyx to close window
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.connect(self.Settings, lambda:_self_.openSettings())
        self.connect(self.Home, lambda:Return_Home(self))
        self.connect(self.List, lambda:List_Selected(self))
		
        Get_Shows(self)
        self.setFocus(self.List)


    def set_info_controls(self):
	
		## create and place a static information able control
        self.Hello = pyxbmct.Label('[UPPERCASE][B]HELLO THERE ' + username + '[/B][/UPPERCASE]', alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.Hello, -4, 1, 2, 21)
		
        self.textbox = pyxbmct.TextBox(textColor='0xFF3E4349')
        self.placeControl(self.textbox, 47, 36, 29, 14)
		
        self.Show_Logo = pyxbmct.Image('')
        self.placeControl(self.Show_Logo, 9, 36, 36, 14)

    def set_active_controls(self):
		
		#Create a single Button Eliment
        self.Settings	= pyxbmct.Button('',	focusTexture=SettingsF,	noFocusTexture=SettingsNF)
        self.Home	= pyxbmct.Button('',	focusTexture=HomeF,	noFocusTexture=HomeNF)
        self.List =	pyxbmct.List(buttonFocusTexture=List_Focused,_space=9,_itemTextYOffset=-7,textColor='0xFF3E4349')

		
		#Place the Single Button Eliment in the Window
        self.placeControl(self.Settings, -9, 44, 13, 7)
        self.placeControl(self.Home, 18, 1, 17, 4)
        self.placeControl(self.List, 9, 7, 80, 28)
		
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.list_update)


    def set_navigation(self):
		
		#set the navigation for if user presses Right when eliment if focused
        self.List.controlLeft(self.Home)
        self.Home.controlRight(self.List)
        self.Settings.controlLeft(self.List)
        self.List.controlRight(self.Settings)
        
		
    def list_update(self):
	
		global media_url
		global media_img
		global media_name
		global media_desc
	
		try:
			if self.getFocus() == self.List:
				position = self.List.getSelectedPosition() - 1
				
				media_name	=	show_one[position]
				media_url	=	show_two[position]
				media_desc	=	show_three[position]
				
				self.textbox.setText(media_desc)
				self.textbox.autoScroll(1000, 1000, 1000)
				
				if show_four[position] is not None:
					media_img	=	show_four[position]
					self.Show_Logo.setImage(media_img)
				else:
					media_img	=	'http://via.placeholder.com/300x220/13b7ff/FFFFFF?text=' + media_name
					self.Show_Logo.setImage(media_img)
					
		except (RuntimeError, SystemError):
			pass