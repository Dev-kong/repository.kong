#############################################################
#################### START ADDON IMPORTS ####################
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import os
import re
import sys
import urllib
import urllib2
import urlparse
import Main
import base64

import pyxbmct.addonwindow as pyxbmct
from addon.common.addon import Addon


#############################################################
#################### SET ADDON ID ###########################
_addon_id_	= 'plugin.video.KongKidz'
_self_			= xbmcaddon.Addon(id=_addon_id_)

#############################################################
#################### SET ADDON THEME DIRECTORY ##############
_theme_			= _self_.getSetting('Theme')
_images_		= '/resources/' + _theme_	
username 		= _self_.getSetting('Username')
_baseURL_       = 'https://pastebin.com/raw/X6Rkh54W'

#############################################################
#################### SET ADDON THEME IMAGES #################
Background_Image	= xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, '2.png'))
UnFocus_Image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 't1.png'))
Focused_image = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 't2.png'))
ButtonF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'b2.png'))
ButtonNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'b1.png'))
SettingsF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'S2.png'))
SettingsNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'S1.png'))
HomeF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'h2.png'))
HomeNF = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'h1.png'))
List_Focused = xbmc.translatePath(os.path.join('special://home/addons/' + _addon_id_ + _images_, 'listf.png'))

#############################################################
########## Function To Call That Starts The Window ##########
def LiveWindow():

    global List
	
    window = Live('KongKidz')
    window.doModal()
    del window
	
def Get_Data(url):

    req = urllib2.Request(url)
    req.add_header(
        'User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36')
    response = urllib2.urlopen(req, timeout=30)
    data = response.read()
    response.close()

    return data
	
def Get_Live(self):

	self.List.reset()
	self.List.setVisible(True)
	self.List.addItem('**** KIDS CHANNELS ****')

##########################: SET GLOBALS
	global show_one
	global show_two
	global show_three
	global show_four
	
	
	show_one	=	[]
	show_two	=	[]
	show_three	=	[]
	show_four	=	[]

	Web_Code = Get_Data(_baseURL_)
	Links = re.findall('<item>(.*?)#(.*?)#(.*?)#(.*?)</item>', Web_Code, re.DOTALL)

	for Link in Links:
	
		show_title = Link[2]
		show_one.append(show_title)
		show_two.append('PLAY:' + Link[0])
		show_three.append(Link[3])
		show_four.append(Link[1])
		self.List.addItem(show_title)
		
#####
def List_Selected(self):
			
	if 'PLAY:' in media_url:
	
			Link_name = media_name
			Link_Image  =	media_img
			Link = media_url.replace('PLAY:','')
			Link_url = Secure_id(Link)
			Show_List	=	xbmcgui.ListItem(Link_name, iconImage=Link_Image,thumbnailImage=Link_Image)
			xbmc.Player().play(Link_url, Show_List, False)
			
def Return_Home(self):

		self.close
		Main.MainWindow()
		

def Secure_id(ID):

	
	Secure_url 	= base64.b64decode('aHR0cHM6Ly93d3cuZmlsbW9uLnR2L2FwaS12Mi9jaGFubmVsLw==') + ID
	
	req = urllib2.Request(Secure_url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/47.0.2526.73 Safari/537.36')
	response = urllib2.urlopen(req, timeout = 30)
	data = response.read()
	response.close()
		
	Link		= find_single_match(data,'"quality":"high","url":"(.*?)"').replace('\/','/')
	return Link
	
def find_single_match(text,pattern):

    result = ""
    try:    
        matches = re.findall(pattern,text, flags=re.DOTALL)
        result = matches[0]
    except:
        result = ""

    return result
			
#############################################################
######### Class Containing the GUi Code / Controls ##########
class Live(pyxbmct.AddonFullWindow):

    def __init__(self, title='KongKidz'):
        super(Live, self).__init__(title)
		
		#set the location and size of your window in kodi
        self.setGeometry(1280, 720, 100, 50)
		
		## Set The backGround Image using PYX Image
        Background			= pyxbmct.Image(Background_Image)
		
		## Place The BackGround Image (X, Y, W, H)
        self.placeControl(Background, -10, -1, 123, 52)
		
		## function to set information controls none interactive
        self.set_info_controls()
		
		## function to set active controls that users interact with 
        self.set_active_controls()
		
		## function to set what happens when users press left,right,up,down on your active controls
        self.set_navigation()
		
		## connect the back button to pyx to close window
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.connect(self.Settings, lambda:_self_.openSettings())
        self.connect(self.Home, lambda:Return_Home(self))
        self.connect(self.List, lambda:List_Selected(self))
		
        Get_Live(self)
        self.setFocus(self.List)


    def set_info_controls(self):
	
		## create and place a static information able control
        self.Hello = pyxbmct.Label('[UPPERCASE][B]HELLO THERE ' + username + '[/B][/UPPERCASE]', alignment=pyxbmct.ALIGN_CENTER)
        self.placeControl(self.Hello, -4, 1, 2, 21)
		
        self.textbox = pyxbmct.TextBox(textColor='0xFF3E4349')
        self.placeControl(self.textbox, 47, 36, 29, 14)
		
        self.Show_Logo = pyxbmct.Image('')
        self.placeControl(self.Show_Logo, 9, 36, 36, 14)

    def set_active_controls(self):
		
		#Create a single Button Eliment
        self.Settings	= pyxbmct.Button('',	focusTexture=SettingsF,	noFocusTexture=SettingsNF)
        self.Home	= pyxbmct.Button('',	focusTexture=HomeF,	noFocusTexture=HomeNF)
        self.List =	pyxbmct.List(buttonFocusTexture=List_Focused,_space=9,_itemTextYOffset=-7,textColor='0xFF3E4349')

		
		#Place the Single Button Eliment in the Window
        self.placeControl(self.Settings, -9, 44, 13, 7)
        self.placeControl(self.Home, 18, 1, 17, 4)
        self.placeControl(self.List, 9, 7, 75, 28)
		
        self.connectEventList(
            [pyxbmct.ACTION_MOVE_DOWN,
             pyxbmct.ACTION_MOVE_UP,
             pyxbmct.ACTION_MOUSE_WHEEL_DOWN,
             pyxbmct.ACTION_MOUSE_WHEEL_UP,
             pyxbmct.ACTION_MOUSE_MOVE],
            self.list_update)


    def set_navigation(self):
		
		#set the navigation for if user presses Right when eliment if focused
        self.List.controlLeft(self.Home)
        self.Home.controlRight(self.List)
        self.Settings.controlLeft(self.List)
        self.List.controlRight(self.Settings)
        
		
    def list_update(self):
	
		global media_url
		global media_img
		global media_name
		global media_desc
	
		try:
			if self.getFocus() == self.List:
				position = self.List.getSelectedPosition() - 1
				
				media_name	=	show_one[position]
				media_url	=	show_two[position]
				media_desc	=	show_three[position]
				
				self.textbox.setText(media_desc)
				self.textbox.autoScroll(1000, 1000, 1000)
				
				if show_four[position] is not None:
					media_img	=	show_four[position]
					self.Show_Logo.setImage(media_img)
				else:
					media_img	=	'http://via.placeholder.com/300x220/13b7ff/FFFFFF?text=' + media_name
					self.Show_Logo.setImage(media_img)
					
		except (RuntimeError, SystemError):
			pass